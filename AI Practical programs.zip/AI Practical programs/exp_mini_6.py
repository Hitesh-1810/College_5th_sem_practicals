# Step 1: Create a list to hold student records
students = []

# Step 2: Add a student record
def add_student(roll_number, name, age, branch, contact_number, blood_group):
    student = {
        'roll_number': roll_number,
        'name': name,
        'age': age,
        'branch': branch,
        'contact_number': contact_number,
        'blood_group': blood_group
    }
    students.append(student)
    print("Student added successfully.")

# Step 3: View all student records
def view_students():
    if students:
        print("\n--- Student Records ---")
        for idx, student in enumerate(students, start=1):  # ID starts from 1
            print(f"ID: {idx}, Roll Number: {student['roll_number']}, Name: {student['name']}, Age: {student['age']}, Branch: {student['branch']}, Contact: {student['contact_number']}, Blood Group: {student['blood_group']}")
    else:
        print("No records found.")

# Step 4: Search for a student using various criteria excluding Blood Group
def search_student(criteria, value):
    found = False
    print(f"\n--- Search Results for {criteria} = {value} ---")
    
    for idx, student in enumerate(students, start=1):  # ID starts from 1
        if (
            (criteria == "ID" and idx == int(value)) or
            (criteria == "Roll Number" and student['roll_number'] == int(value)) or
            (criteria == "Name" and student['name'].lower() == value.lower()) or
            (criteria == "Contact Number" and student['contact_number'] == value)
        ):
            print(f"ID: {idx}, Roll Number: {student['roll_number']}, Name: {student['name']}, Age: {student['age']}, Branch: {student['branch']}, Contact: {student['contact_number']}, Blood Group: {student['blood_group']}")
            found = True
    
    if not found:
        print("No matching student found.")

# Step 5: Update student details by ID or Roll Number
def update_student(identifier, is_roll_number=True, name=None, age=None, branch=None, contact_number=None, blood_group=None):
    for idx, student in enumerate(students):
        # Convert 1-based ID to 0-based index
        if (is_roll_number and student['roll_number'] == identifier) or (not is_roll_number and idx + 1 == identifier):
            if name: student['name'] = name
            if age is not None: student['age'] = age
            if branch: student['branch'] = branch
            if contact_number: student['contact_number'] = contact_number
            if blood_group: student['blood_group'] = blood_group
            print("Student updated successfully.")
            return
    print("Student not found.")

# Step 6: Delete a student by ID or Roll Number
def delete_student(identifier, is_roll_number=True):
    for idx, student in enumerate(students):
        # Convert 1-based ID to 0-based index
        if (is_roll_number and student['roll_number'] == identifier) or (not is_roll_number and idx + 1 == identifier):
            students.pop(idx)  # Remove student at 0-based index
            print("Student deleted successfully.")
            return
    print("Student not found.")

# Step 7: Menu for the system
def menu():
    while True:
        print("\n--- Student Information Management System ---")
        print("1. Add Student")
        print("2. View Students")
        print("3. Search Student")
        print("4. Update Student by ID or Roll Number")
        print("5. Delete Student by ID or Roll Number")
        print("6. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            roll_number = int(input("Enter Roll Number: "))
            name = input("Enter Name: ")
            age = int(input("Enter Age: "))
            branch = input("Enter Branch: ")
            contact_number = input("Enter Contact Number: ")
            blood_group = input("Enter Blood Group: ")
            add_student(roll_number, name, age, branch, contact_number, blood_group)

        elif choice == '2':
            view_students()

        elif choice == '3':
            print("\nSearch by:")
            print("1. ID")
            print("2. Roll Number")
            print("3. Name")
            print("4. Contact Number")
            search_choice = input("Choose an option: ")

            if search_choice == '1':
                student_id = input("Enter Student ID: ")
                search_student("ID", student_id)

            elif search_choice == '2':
                roll_number = input("Enter Roll Number: ")
                search_student("Roll Number", roll_number)

            elif search_choice == '3':
                name = input("Enter Name: ")
                search_student("Name", name)

            elif search_choice == '4':
                contact_number = input("Enter Contact Number: ")
                search_student("Contact Number", contact_number)

            else:
                print("Invalid choice! Please try again.")

        elif choice == '4':
            update_choice = input("Do you want to update by (1) Roll Number or (2) ID? ")
            if update_choice == '1':
                roll_number = int(input("Enter Roll Number to Update: "))
                name = input("Enter New Name (or leave blank to skip): ")
                age = input("Enter New Age (or leave blank to skip): ")
                branch = input("Enter New Branch (or leave blank to skip): ")
                contact_number = input("Enter New Contact Number (or leave blank to skip): ")
                blood_group = input("Enter New Blood Group (or leave blank to skip): ")
                update_student(roll_number, name=name or None, age=int(age) if age else None, branch=branch or None, contact_number=contact_number or None, blood_group=blood_group or None)

            elif update_choice == '2':
                student_id = int(input("Enter Student ID to Update: "))
                name = input("Enter New Name (or leave blank to skip): ")
                age = input("Enter New Age (or leave blank to skip): ")
                branch = input("Enter New Branch (or leave blank to skip): ")
                contact_number = input("Enter New Contact Number (or leave blank to skip): ")
                blood_group = input("Enter New Blood Group (or leave blank to skip): ")
                update_student(student_id, is_roll_number=False, name=name or None, age=int(age) if age else None, branch=branch or None, contact_number=contact_number or None, blood_group=blood_group or None)

            else:
                print("Invalid choice! Please try again.")

        elif choice == '5':
            delete_choice = input("Do you want to delete by (1) Roll Number or (2) ID? ")
            if delete_choice == '1':
                roll_number = int(input("Enter Roll Number to Delete: "))
                delete_student(roll_number)

            elif delete_choice == '2':
                student_id = int(input("Enter Student ID to Delete: "))
                delete_student(student_id, is_roll_number=False)

            else:
                print("Invalid choice! Please try again.")

        elif choice == '6':
            print("Thank You")
            break

        else:
            print("Student Information Management System is STOP")

# Run the program
if __name__ == "__main__":
    menu()
