class Node:
    def __init__(self, data, level, fval):
        """ Initialize the node with the data, level of the node, and the calculated fvalue """
        self.data = data
        self.level = level
        self.fval = fval

    def generate_child(self):
        """ Generate child nodes from the given node by moving the blank space
            either in the four directions {up, down, left, right} """
        x, y = self.find(self.data, '-')
        val_list = [[x, y-1], [x, y+1], [x-1, y], [x+1, y]]
        children = []
        for i in val_list:
            child = self.shuffle(self.data, x, y, i[0], i[1])
            if child is not None:
                child_node = Node(child, self.level+1, 0)
                children.append(child_node)
        return children

    def shuffle(self, puz, x1, y1, x2, y2):
        """ Move the blank space in the given direction and return new state if valid """
        if x2 >= 0 and x2 < len(self.data) and y2 >= 0 and y2 < len(self.data):
            temp_puz = self.copy(puz)
            temp_puz[x1][y1], temp_puz[x2][y2] = temp_puz[x2][y2], temp_puz[x1][y1]
            return temp_puz
        else:
            return None

    def copy(self, root):
        """ Copy function to create a similar matrix of the given node """
        return [row[:] for row in root]

    def find(self, puz, x):
        """ Find the position of the blank space """
        for i in range(len(self.data)):
            for j in range(len(self.data)):
                if puz[i][j] == x:
                    return i, j


class Puzzle:
    def __init__(self, size):
        """ Initialize the puzzle size, open and closed lists """
        self.n = size
        self.open = []
        self.closed = []

    def accept(self):
        """ Accepts the puzzle input from the user """
        puz = []
        for i in range(self.n):
            temp = input().split(" ")
            puz.append(temp)
        return puz

    def f(self, start, goal):
        """ Heuristic function f(x) = h(x) + g(x) """
        return self.h(start.data, goal) + start.level

    def h(self, start, goal):
        """ Calculates the difference between the given puzzles """
        temp = 0
        for i in range(self.n):
            for j in range(self.n):
                if start[i][j] != goal[i][j] and start[i][j] != '-':
                    temp += 1
        return temp

    def process(self):
        """ Accept Start and Goal Puzzle state, and solve using A* """
        print("Enter the start state matrix:")
        start = self.accept()
        print("Enter the goal state matrix:")
        goal = self.accept()

        start = Node(start, 0, 0)
        start.fval = self.f(start, goal)
        self.open.append(start)

        while True:
            cur = self.open[0]
            print("\nCurrent state (fval={}):".format(cur.fval))
            for row in cur.data:
                print(" ".join(row))

           
            if self.h(cur.data, goal) == 0:
                print("\nGoal state reached!")
                break

           
            for child in cur.generate_child():
                child.fval = self.f(child, goal)
                self.open.append(child)

           
            self.closed.append(cur)
            del self.open[0]

            
            self.open.sort(key=lambda x: x.fval)


puz = Puzzle(3)
puz.process()
